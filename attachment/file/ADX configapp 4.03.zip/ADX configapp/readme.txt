
1.press your adx no.3 and no.4 buttons and plug in cable make adx in to update mode

2.run IPS-TOOLS and choose firmware (i recommend 4.03 reverse) and start ,wait it success

3.after update, change [USB port to com 3] and [ch340 to 21] 

4.run configapp and choose ADX

5.you can [change input mode] in main page, and [test touch screen] in test ,even [add TP delay]

6.remember check USB port before game run
