
1.press your adx no.3 and no.4 buttons and plug in cable make adx turn to update mode

2.run IPS-TOOLS and choose firmware (WM_DX_V4.07-COMP.bin) and start ,wait it success

3.after update, change [USB port to com 3] and [ch340 to 21] 

4.run configapp and choose ADX

5.you can 
[change 1p2p]
[change input mode] in main page, and 
[test touch screen] in test ,
even [add TP delay](io mode+5ms)(keybaord mode +15ms)

6.remember check USB port before game run
